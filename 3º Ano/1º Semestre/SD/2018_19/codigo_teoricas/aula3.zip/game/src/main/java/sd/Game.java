package sd;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.Collectors;

public class Game {
    private static class Coords {
        final int x, y;

        public Coords(int x, int y) {
            this.x=x;
            this.y=y;
        }
    }
    private static class PLayer {
        Coords xy;
        int shots = 10, score = 0;

        void move() {
            xy = new Coords(xy.x+1, xy.y+1);
        }
    };

    private Lock l = new ReentrantLock();

    private Map<String,PLayer> players = new HashMap<String, PLayer>();

    public void start(String name) {
        try { l.lock();
            players.put(name, new PLayer());
        } finally { l.unlock(); }
    }

    public void draw() {
        List<Coords> c;
        try { l.lock();
            c = players.values().stream().map(p -> p.xy).collect(Collectors.toList());
        } finally { l.unlock(); }

        c.forEach(p->drawPlayer(p.x, p.y));
    }

    public void move(String name) {
        try { l.lock();
            players.get(name).move();
        } finally { l.unlock(); }
    }

    //---

    public void drawPlayer(int x, int y) {
        System.out.println(x+", "+y);
    }
}

