package sd;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.Collectors;

public class GameV3 {
    private static class Coords {
        final int x, y;

        public Coords(int x, int y) {
            this.x=x;
            this.y=y;
        }
    }
    private static class PLayer {
        Lock l = new ReentrantLock();

        Coords xy;
        int life = 10, score = 0;

        void move() {
            try { l.lock();
                xy = new Coords(xy.x+1, xy.y+1);
            } finally{ l.unlock(); }
        }

        public Coords getXY() {
            try { l.lock();
                return xy;
            } finally{ l.unlock(); }
        }
    };


    private Map<String,PLayer> players = new HashMap<String, PLayer>();

    public void draw() {
        List<Coords> c;
        c = players.values().stream().map(p -> p.getXY()).collect(Collectors.toList());

        c.forEach(p->drawPlayer(p.x, p.y));
    }

    public void move(String name) {
        players.get(name).move();
    }

    public void shoot(String sn, String tn) {
        PLayer s = players.get(sn);
        PLayer t = players.get(tn);
        try { s.l.lock();
            try { t.l.lock();
            s.score++;
            t.life--;
        } finally{ t.l.unlock(); }
        } finally{ s.l.unlock(); }
    }

    //---

    public void drawPlayer(int x, int y) {
        System.out.println(x+", "+y);
    }
}

