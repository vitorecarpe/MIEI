package sd;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

// Exemplo de servidor concorrente: 1 thread por ligação

public class Server implements Runnable {
    private final Socket s;

    public Server(Socket s) {
        this.s = s;
    }

    public static void main(String[] args) throws Exception {
        ServerSocket ss = new ServerSocket(12345);

        while(true) {

            Socket s = ss.accept();

            new Thread(new Server(s)).start();
        }
    }

    public void run() {
        try {
            PrintWriter w = new PrintWriter(s.getOutputStream());
            BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream()));

            String v = r.readLine();

            v = v.toUpperCase();
            Thread.sleep(1000);

            w.println(v);
            w.flush();

            s.close();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
