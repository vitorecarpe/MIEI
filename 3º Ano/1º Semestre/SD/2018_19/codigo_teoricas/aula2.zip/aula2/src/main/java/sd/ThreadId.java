package sd;

public class ThreadId {
    public static int max() {
        // magia...
        return 0;
    }

    public static int get() {
        // magia...
        return 0;
    }
}
