package sd;

public interface Lock {
    void lock();
    void unlock();
}
