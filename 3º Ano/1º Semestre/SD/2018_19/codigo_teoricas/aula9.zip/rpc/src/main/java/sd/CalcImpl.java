package sd;

public class CalcImpl implements Calc {
    @Override
    public int div(int o1, int o2) {
        return o1/o2;
    }

    @Override
    public double sqrt(int o) {
        return Math.sqrt(o);
    }
}
