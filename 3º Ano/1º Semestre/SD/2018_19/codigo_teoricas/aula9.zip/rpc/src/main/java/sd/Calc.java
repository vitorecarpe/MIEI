package sd;

import java.io.IOException;

public interface Calc {
    int div(int o1, int o2);
    double sqrt(int o);
}
