package sd;

import java.lang.reflect.Method;

/*
    Demosntração de reflexão em Java: Em princípio,  interface pode ser
    usada para gerar o código para invocação remota.

    (Na prática não se gera código-fonte Java. Gera-se diretamente o bytecode.)
 */
public class ReflectionDemo {
    public static void main(String[] args) throws Exception {
        Class c = Calc.class;

        System.out.println("public class "+c.getSimpleName()+"Stub {");

        for(Method m: c.getMethods()) {
            System.out.println("   public "+m.getReturnType().getSimpleName()+
                    " "+m.getName()+"( ... ) {");
            System.out.println(    "}");
            System.out.println();
        }

        System.out.println("}");
    }
}
