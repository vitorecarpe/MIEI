package sd;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

// Exemplo de servidor concorrente: 1 thread por ligação

public class Server implements Runnable {
    private final Socket s;

    public Server(Socket s) {
        this.s = s;
    }

    public static void main(String[] args) throws Exception {
        ServerSocket ss = new ServerSocket(12345);

        while(true) {
            Socket s = ss.accept();
            new Thread(new Server(s)).start();
        }
    }

    public void run() {
        Calc c = new CalcImpl();

        try {
            PrintWriter w = new PrintWriter(s.getOutputStream());
            BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream()));

            String v = r.readLine();

            String[] p = v.split(" ");
            switch(p[0]) {
                case "div":
                    int o1 = Integer.parseInt(p[1]);
                    int o2 = Integer.parseInt(p[2]);
                    int resmul = c.div(o1,o2);
                    v = Integer.toString(resmul);
                    break;
                case "sqrt":
                    int o = Integer.parseInt(p[1]);
                    double ressqrt = c.sqrt(o);
                    v = Double.toString(ressqrt);
                    break;
                default:
                    // error
            }

            w.println(v);
            w.flush();

            s.close();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
