package sd;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class CalcStub implements Calc {
    private final Socket s;
    private final PrintWriter w;
    private final BufferedReader r;

    public CalcStub() throws Exception {
        s = new Socket("localhost", 12345);

        w = new PrintWriter(s.getOutputStream());
        r = new BufferedReader(new InputStreamReader(s.getInputStream()));
    }

    @Override
    public int div(int o1, int o2) {
        String ped = "div ";
        ped+=Integer.toString(o1);
        ped+=" ";
        ped+=Integer.toString(o2);

        w.println(ped);
        w.flush();

        String res = null;
        try {
            res = r.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return Integer.parseInt(res);
    }

    @Override
    public double sqrt(int o) {
        String ped = "sqrt ";
        ped+=Integer.toString(o);

        w.println(ped);
        w.flush();

        String res = null;
        try {
            res = r.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return Double.parseDouble(res);
    }
}
