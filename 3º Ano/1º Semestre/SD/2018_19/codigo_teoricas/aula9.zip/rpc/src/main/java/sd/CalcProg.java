package sd;

public class CalcProg {
    public static void main(String[] args) throws Exception {
        //Calc c = new CalcImpl();
        Calc c = new CalcStub();

        System.out.println("o resultado e "+c.div(1,0));
    }
}
