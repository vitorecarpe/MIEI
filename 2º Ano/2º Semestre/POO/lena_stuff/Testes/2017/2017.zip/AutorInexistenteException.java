
/**
 * Write a description of class AutorInexistenteException here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class AutorInexistenteException extends Exception {
    public AutorInexistenteException() {
    }

    public AutorInexistenteException(String msg) {
        super(msg);
    }

    public AutorInexistenteException(Throwable cause) {
        super(cause);
    }

    public AutorInexistenteException(String msg, Throwable cause) {
        super(msg, cause);
    }
}
