// Exemplo de como criar uma exceçao simples
public class RamdomException extends Exception
{
    public RamdomException() {
        super();
    }
    public RamdomException(String s) {
        super(s);
    }
}
